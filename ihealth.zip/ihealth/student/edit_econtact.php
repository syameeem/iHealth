<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/logo.png">
  <link rel="icon" type="image/png" href="./assets/img/logo.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    iHealth
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <!-- user panel -->
      <?php include ('panel.php'); ?>
      <!-- end user panel -->
      <!--side bar-->
      <div class="sidebar-wrapper">
        <?php include 'sidebar.php' ?>
      </div>
      <!--end side bar-->
    </div>
    <div class="main-panel" style="height: 100vh;">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">EMERGENCY CONTACT > ADD CONTACT</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
              <div class="input-group no-border">
                <?php include 'searchbar.php' ?>
              </div>
            </form>
            <ul class="navbar-nav">
             <?php include 'notification.php' ?>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <!-- body -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
          <div class="col-md-8">
            <div class="card card-user col-md-20">
              <div class="card-header">
                <h5 class="card-title">Edit Contact</h5>
              </div>
              <!--Edit action -->
              <?php
                  include ('connection.php');

                  $query = 'SELECT * FROM relativectc
                  WHERE eid ='.$_GET['id'];
                  $result = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result))
                    {   
                      $eid = $row['eid'];
                      $ename = $row['ename'];
                      $etelno = $row['etelno'];
                      $erelationship = $row['erelationship'];
                    }         
                  $eid = $_GET['id'];

                  if(isset($_POST['submit'])) 
                  {
                    $ename = strtoupper($_POST['ename']);
                    $erelationship = strtoupper($_POST['erelationship']);
                    $etelno = $_POST['etelno'];

                    $sql = "UPDATE relativectc
                            SET ename = '$ename', erelationship='$erelationship', etelno='$etelno'
                            WHERE eid ='$eid'";

                    if (mysqli_query($conn, $sql))
                    {?>
                      <div class="alert alert-success alert-dismissible fade show">
                        <button type="button" aria-hidden="true" class="close col-md-4" data-dismiss="alert" aria-label="Close" onclick="demo.showNotification('bottom','center')">
                          <i class="nc-icon nc-simple-remove"></i>
                        </button>
                        <b> Success - </b> Medicine details is up to date!
                      </div>
                    <?php
                    }
                    
                    else
                    {?>
                      <div class="alert alert-danger alert-dismissible fade show">
                        <button type="button" aria-hidden="true" class="close col-md-4" data-dismiss="alert" aria-label="Close" onclick="demo.showNotification('bottom','center')">
                          <i class="nc-icon nc-simple-remove"></i>
                        </button>
                        <b> Error - </b> Medicine can not be edited.
                      </div>
                    <?php
                       // echo "Error: " . $sql . ":-" . mysqli_error($conn);
                    }

                    mysqli_close($conn);
                  }
              ?>
              <!-- end Edit action -->
              <div class="card-body">
                <form action="#" method="post">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="ename" value="<?php echo $ename ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Relationship</label>
                        <select name="erelationship" type="text" class="form-control"><?php echo $erelationship ?>
                          <option value="parent">Parent</option>
                          <option value="sibling">Sibling</option>
                          <option value="partner">Partner</option>
                          <option value="friend">Friend</option>
                          <option value="housemate">Housemate</option>
                          <option value="others">Others</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Contact Number</label>
                        <input type="text" class="form-control" name="etelno" value="<?php echo $etelno ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="update ml-auto mr-auto">
                      <button type="submit" name ="submit" value="submit" class="btn btn-primary btn-round">save changes</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      <!-- end body -->
      <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
        <?php include 'footer.php' ?>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="./assets/js/core/jquery.min.js"></script>
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="./assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
</body>

</html>