<!-- <?php
session_start();
include ('connection.php');

if(isset($_POST['submit'])) 
{
    $studentid = $_POST['studentid'];
    $studentpassword = $_POST['studentpassword'];

    $encryptedPassword = md5($studentpassword);

    $sql = "SELECT * FROM student
            WHERE studentid = '$studentid' AND studentpassword = '$encryptedPassword'";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) 
    {
        $row = mysqli_fetch_assoc($result);
        $_SESSION["studentid"] = $row['studentid'];
        $_SESSION["studentname"] = $row['studentname'];
        $_SESSION["studenttelno"] = $row['studenttelno'];
        header("Location: view_profile.php");
        exit;
    } 
    else 
    {
?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" aria-hidden="true" class="close col-md-4" data-dismiss="alert" aria-label="Close" onclick="demo.showNotification('bottom','center')">
                <i class="nc-icon nc-simple-remove"></i>
            </button>
            <b> Error - </b> Invalid Credentials.
        </div>
<?php
    }
}
mysqli_close($conn);
?> -->
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/logo.png.png">
  <link rel="icon" type="image/png" href="./assets/img/logo.png.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    iHealth
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
</head>
<body class="">
<div class="content">
    <div class="row">
        <div class="update ml-auto mr-auto">
                <div class="card">
                    <div class="card-header">
                        <img style="display:block; margin:0 auto; width:50%; height:50%;" class="avatar border-gray" src="./assets/img/logo.png" alt="..."><h6 style="text-align:center;">UiTM jasin Healthcare Tracker System</h6>
                        <h5 class="card-title" style="text-align: center;">STUDENT LOGIN</h5>
                    </div>
                    <div class="card-body">
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-md-auto update ml-auto mr-auto">
                                    <div class="form-group">
                                        <label>Student ID</label>
                                        <input type="text" class="form-control" placeholder="Enter ID" name="studentid">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-auto update ml-auto mr-auto">
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" class="form-control" placeholder="Enter Password" name="studentpassword">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="update ml-auto mr-auto">
                                    <button type="submit" name="submit" value="submit" class="btn btn-primary btn-round">LOGIN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end login form -->
      <!--add action -->
      <?php
                  include ('connection.php');
                  if(isset($_POST['submit'])) 
                  {
                    $studentid = mysqli_real_escape_string($conn, $_POST['studentid']);
                    $studentpassword = mysqli_real_escape_string($conn, $_POST['studentpassword']);
                    $encryptedPassword = md5($studentpassword);
                    $sql = "SELECT * FROM student WHERE studentid = '$studentid' AND studentpassword = '$encryptedPassword'";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        $row = mysqli_fetch_assoc($result);
                        $_SESSION["studentid"] = $row['studentid'];
                        $_SESSION['studentname'] = $row['studentname'];
                        $_SESSION['studenttelno'] = $row['studenttelno'];
                        mysqli_free_result($result);
                        mysqli_close($conn);
                        header("location:view_profile.php?id=" . $row['studentid']);
                        exit();
                    } else {
            ?>
                      <div class="alert alert-danger alert-dismissible fade show">
                        <button type="button" aria-hidden="true" class="close col-md-4" data-dismiss="alert" aria-label="Close" onclick="demo.showNotification('bottom','center')">
                          <i class="nc-icon nc-simple-remove"></i>
                        </button>
                        <b> Error - </b> Invalid credentials.
                      </div>
                    <?php
                       // echo "Error: " . $sql . ":-" . mysqli_error($conn);
                    }
                    mysqli_close($conn);
                  }
              ?>
              <!-- end add action -->
      <!-- end body -->
      <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
        <?php include 'footer.php' ?>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="./assets/js/core/jquery.min.js"></script>
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="./assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
</body>

</html>