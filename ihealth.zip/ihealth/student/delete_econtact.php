<?php
    include ('connection.php');
	if (!isset($_GET['do']) || $_GET['do'] != 1) 
	{
			$query ="DELETE FROM relativectc
					WHERE eid = " . $_GET['id'];
			$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
			?>

			<script type="text/javascript">
				alert("Successfully Deleted.");
				window.location = "view_econtact.php";
			</script>	

		<?php
	}
?>