<ul class="nav">

  <li>
    <a href="view_treatment.php">
      <i class="nc-icon nc-paper"></i>
      <p>Treatment History</p>
    </a>
  </li>

  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-mobile"></i>
      <p>emergency contact</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="add_econtact.php">Add Emergency Contact</a>
        <a class="dropdown-item" href="view_econtact.php">View Emergency Contact</a>
      </div>
    </a>
  </li>

  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-sound-wave"></i>
      <p>health info</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="view_hinfo.php">View Health Information</a>
        <a class="dropdown-item" href="edit_hinfo.php">Edit Health Information</a>
      </div>
    </a>
  </li>

  <li>
    <a href="qrcode.php">
      <i class="nc-icon nc-layout-11"></i>
      <p>QR code</p>
    </a>
  </li>

  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-single-02"></i>
      <p>my profile</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="view_profile.php">View Profile</a>
        <a class="dropdown-item" href="edit_profile.php">Edit Profile</a>
      </div>
    </a>
  </li>

  <li>
    <a href="logout.php">
      <i class="nc-icon nc-button-power"></i>
      <p>Logout</p>
    </a>
  </li>
</ul>