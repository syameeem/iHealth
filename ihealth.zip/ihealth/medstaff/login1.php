<?php
session_start();
include ('connection.php');

if(isset($_POST['submit'])) 
{
    $staffid = $_POST['staffid'];
    $staffpassw = $_POST['staffpassw'];

    $encryptedPassword = md5($staffpassw);

    $sql = "SELECT * FROM medstaff
            WHERE staffid = '$staffid' AND staffpassw = '$encryptedPassword'";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) 
    {
        $row = mysqli_fetch_assoc($result);
        $_SESSION["staffid"] = $row['staffid'];
        $_SESSION["staffname"] = $row['staffname'];
        $_SESSION["stafftelno"] = $row['stafftelno'];
        header("Location: view_profile.php");
        exit;
    } 
    else 
    {
?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" aria-hidden="true" class="close col-md-4" data-dismiss="alert" aria-label="Close" onclick="demo.showNotification('bottom','center')">
                <i class="nc-icon nc-simple-remove"></i>
            </button>
            <b> Error - </b> Profile cannot be created.
        </div>
<?php
    }
}
mysqli_close($conn);
?>

<!-- login form -->
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-8">
                <div class="card card-user col-md-20">
                    <div class="card-header">
                        <h5 class="card-title">staff LOGIN</h5>
                    </div>
                    <div class="card-body">
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>staff ID</label>
                                        <input type="text" class="form-control" placeholder="Enter ID" name="staffid">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Passw</label>
                                        <input type="passw" class="form-control" placeholder="Enter Passw" name="staffpassw">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="update ml-auto mr-auto">
                                    <button type="submit" name="submit" value="submit" class="btn btn-primary btn-round">LOGIN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end login form -->
      <!--add action -->
      <?php
                  include ('connection.php');
                  if(isset($_POST['submit'])) 
                  {
                    $staffid = $_POST['staffid'];
                    $staffpassw = $_POST['staffpassw'];

                    $encryptedPassw = md5($staffpassw);

                    $sql = "SELECT *
                            FROM staff
                            WHERE staffid = '$staffid'
                            AND staffpassw = '$encryptedPassw'";

                    if (mysqli_query($conn, $sql)) 
                    {?>
                      <div class="alert alert-success alert-dismissible fade show">
                        <button type="button" aria-hidden="true" class="close col-md-4" data-dismiss="alert" aria-label="Close" onclick="demo.showNotification('bottom','center')">
                        <a href="view_profile.php?id=<?php $row['staffid']; ?>">Edit</a>
                          <i class="nc-icon nc-simple-remove"></i>
                        </button>
                        <b> Success</b>
                        <?php 
                              $_SESSION['staffid'] = $row['staffid'];
                              $_SESSION['staffname'] = $row['staffname'];
                              $_SESSION['stafftelno'] = $row['stafftelno'];
                              //$hashed_passw = $row['staffpassw'];
                              //$hashed_input_passw = hash('sha256', $passw);
                              header("location:view_profile.php");
                          ?>
                      </div>
                    <?php 
                    }
                    
                    else
                    {?>
                      <div class="alert alert-danger alert-dismissible fade show">
                        <button type="button" aria-hidden="true" class="close col-md-4" data-dismiss="alert" aria-label="Close" onclick="demo.showNotification('bottom','center')">
                          <i class="nc-icon nc-simple-remove"></i>
                        </button>
                        <b> Error - </b> Profile can not be created.
                      </div>
                    <?php
                       // echo "Error: " . $sql . ":-" . mysqli_error($conn);
                    }
                    mysqli_close($conn);
                  }

                  //if(isset($_SESSION["staffid"]))
                  //{  
                   // header("location:view_profile.php");
                 // }
              ?>
              <!-- end add action -->
      <!-- end body -->
      <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
        <?php include 'footer.php' ?>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="./assets/js/core/jquery.min.js"></script>
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="./assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
</body>

</html>