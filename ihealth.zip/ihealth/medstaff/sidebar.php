<ul class="nav">
  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-paper"></i>
      <p>Treatment</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="add_report.php">Add Treatment</a>
        <a class="dropdown-item" href="view_treatment.php">View Treatment</a>
      </div>
    </a>
  </li>

  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-single-02"></i>
      <p>my profile</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="view_profile.php">View Profile</a>
        <a class="dropdown-item" href="edit_profile.php">Edit Profile</a>
      </div>
    </a>
  </li>

  <li>
    <a href="logout.php">
      <i class="nc-icon nc-button-power"></i>
      <p>Logout</p>
    </a>
  </li>
</ul>