<?php
session_start();

if (!isset($_SESSION['staffid'])) {
  header('Location: login.php');
  exit;
}
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/logo.png">
  <link rel="icon" type="image/png" href="./assets/img/logo.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    iHealth
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <!-- user panel -->
      <?php include ('panel.php'); ?>
      <!-- end user panel -->
      <!--side bar-->
      <div class="sidebar-wrapper">
        <?php include 'sidebar.php' ?>
      </div>
      <!--end side bar-->
    </div>
    <div class="main-panel" style="height: 100vh;">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">PROFILE > EDIT PROFILE</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
              <div class="input-group no-border">
                <?php include 'searchbar.php' ?>
              </div>
            </form>
            <ul class="navbar-nav">
             <?php include 'notification.php' ?>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <!-- body -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
          <div class="col-md-8">
            <div class="card card-user col-md-20">
              <div class="card-header">
                <h5 class="card-title">Edit Profile</h5>
              </div>
              <!--Edit action -->
              <?php
                  include ('connection.php');

                  $query = 'SELECT * FROM medstaff
                  WHERE staffid ='.$_SESSION['staffid'];
                  $result = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result))
                    {   
                      $staffid = $row['staffid'];
                      $staffname = $row['staffname'];
                      $staffposition = $row['staffposition'];
                      $stafftelno = $row['stafftelno'];
                      $staffpassw = $row['staffpassw'];
                    }         
                  $staffid = $_SESSION['staffid'];

                  if(isset($_POST['submit'])) 
                  {
                    $staffname = strtoupper($_POST['staffname']);
                    $stafftelno = $_POST['stafftelno'];
                    $staffposition = $_POST['staffposition'];
                    $staffpassw = $_POST['staffpassw'];

                    $encryptedPassword = md5($staffpassw);

                    $sql = "UPDATE medstaff 
                            SET staffname = '$staffname', stafftelno='$stafftelno', staffposition='$staffposition', staffpassw='$encryptedPassword'
                            WHERE staffid ='$staffid'";

                    if (mysqli_query($conn, $sql)) {
                        echo "New record has been edited successfully !";
                    } else {
                        echo "Error: " . $sql . ":-" . mysqli_error($conn);
                    }
                    mysqli_close($conn);
                  }
              ?>
              <!-- end Edit action -->
              <div class="card-body">
                <form action="#" method="post">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>staff ID</label>
                        <input type="text" class="form-control"  disabled="" name="staffid" value="<?php echo $staffid ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Staff Name</label>
                        <input type="text" class="form-control" name="staffname" value="<?php echo $staffname ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Contact Number</label>
                        <input type="text" class="form-control" name="stafftelno" value="0<?php echo $stafftelno ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Position</label>
                        <select name="staffposition" type="text" class="form-control"><?php echo $staffposition ?>
                          <option value="nurse">Nurse</option>
                          <option value="pharmacist">Pharmacist</option>
                          <option value="doctor">Doctor</option>
                          <option value="medical assistant">Medical Assistant</option>
                        </select>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="staffpassw" value="<?php echo $staffpassw ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="update ml-auto mr-auto">
                      <button type="submit" name ="submit" value="submit" class="btn btn-primary btn-round">save changes</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      <!-- end body -->
      <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
        <?php include 'footer.php' ?>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="./assets/js/core/jquery.min.js"></script>
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="./assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
</body>

</html>