<!--<?php
    if(!isset($_SESSION)){
        session_start();
        ?>
        <div>Welcome, <?php echo $_SESSION['adminname'] ?>!</div>
    <?php
    }
?>-->