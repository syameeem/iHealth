<?php 
session_start();
if((isset($_SESION["adminid"]) && isset($_SESSION["encryptedpassword"]))){
	$myid = $_SESSION['adminid'];
    $myname = $_SESSION['adminname'];
    $mycontact = $_SESSION['admintelno'];
}else {
	header("location:login.php");
}
?>