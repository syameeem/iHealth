<ul class="nav">
  <li>
    <a href="view_student.php">
      <i class="nc-icon nc-ambulance"></i>
      <p>Patient</p>
    </a>
  </li>

  <li>
    <a href="view_treatment.php">
      <i class="nc-icon nc-paper"></i>
      <p>Treatment</p>
    </a>
  </li>

  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-atom"></i>
      <p>medicine</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="add_medicine.php">Add Medicine</a>
        <a class="dropdown-item" href="view_medicine.php">View Mecidine</a>
      </div>
    </a>
  </li>

  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-badge"></i>
      <p>users</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="add_medstaff.php">Add Medical Staff</a>
        <a class="dropdown-item" href="add_admin.php">Add Admin</a>
        <a class="dropdown-item" href="add_student.php">Add Student</a>
        <a class="dropdown-item" href="view_users.php">Manage Users</a>
      </div>
    </a>
  </li>

  <li class="nav-item btn-rotate dropdown">
    <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="nc-icon nc-single-02"></i>
      <p>my profile</p>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="view_profile.php">View Profile</a>
        <a class="dropdown-item" href="edit_profile.php">Edit Profile</a>
      </div>
    </a>
  </li>

  <li>
    <a href="logout.php">
      <i class="nc-icon nc-button-power"></i>
      <p>Logout</p>
    </a>
  </li>
</ul>