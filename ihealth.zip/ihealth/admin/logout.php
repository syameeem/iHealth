<?php
  include ('connection.php');
    session_start();
    session_destroy();
    unset($_SESSION["adminid"]);
    unset($_SESSION["studentid"]);
    unset($_SESSION["staffid"]);
    header("Location:login.php");
?>