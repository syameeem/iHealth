
        <div class="container-fluid">
          <div class="row">
            <nav class="footer-nav">
              <ul>
                <li><a href="#" target="_blank">iHealth - Healthcare Tracker System</a></li>
              </ul>
            </nav>
            <div class="credits ml-auto">
              <span class="copyright">
                © 2023, Version 1.0
              </span>
            </div>
          </div>
        </div>